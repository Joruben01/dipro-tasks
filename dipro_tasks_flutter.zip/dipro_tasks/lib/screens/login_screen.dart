import 'package:flutter/material.dart';
import 'package:dipro_tasks/models/models.dart';
import 'package:dipro_tasks/services/data_service.dart';
import 'package:dipro_tasks/screens/home_shell.dart';
import 'package:dipro_tasks/theme.dart';

class LoginScreen extends StatefulWidget {
  final DataService dataService;
  final bool modoOscuro;
  final ValueChanged<bool> onCambiarModoOscuro;

  const LoginScreen({
    super.key,
    required this.dataService,
    required this.modoOscuro,
    required this.onCambiarModoOscuro,
  });

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usuarioCtrl = TextEditingController(text: 'jorge');
  final _passCtrl = TextEditingController(text: '1234');
  bool _cargando = false;
  String? _error;

  Future<void> _ingresar() async {
    setState(() {
      _cargando = true;
      _error = null;
    });
    final usuario = await widget.dataService.login(_usuarioCtrl.text.trim(), _passCtrl.text.trim());
    setState(() => _cargando = false);
    if (usuario == null) {
      setState(() => _error = 'Usuario o contrasena incorrectos');
      return;
    }
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => HomeShell(
        usuario: usuario,
        dataService: widget.dataService,
        modoOscuro: widget.modoOscuro,
        onCambiarModoOscuro: widget.onCambiarModoOscuro,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              color: DiproColors.azul,
              padding: const EdgeInsets.symmetric(vertical: 40),
              child: Column(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: DiproColors.rojo,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    alignment: Alignment.center,
                    child: const Text('DT',
                        style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w600)),
                  ),
                  const SizedBox(height: 12),
                  const Text('Dipro Tasks',
                      style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 12),
                    TextField(
                      controller: _usuarioCtrl,
                      decoration: const InputDecoration(labelText: 'Usuario', border: OutlineInputBorder()),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _passCtrl,
                      obscureText: true,
                      decoration: const InputDecoration(labelText: 'Contrasena', border: OutlineInputBorder()),
                    ),
                    if (_error != null) ...[
                      const SizedBox(height: 12),
                      Text(_error!, style: const TextStyle(color: DiproColors.rojo)),
                    ],
                    const SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: _cargando ? null : _ingresar,
                      child: _cargando
                          ? const SizedBox(
                              height: 18, width: 18,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                          : const Text('Ingresar'),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text('Modo oscuro'),
                        Switch(
                          value: widget.modoOscuro,
                          onChanged: widget.onCambiarModoOscuro,
                          activeColor: DiproColors.rojo,
                        ),
                      ],
                    ),
                    const Spacer(),
                    const Text('v1.0 beta interna DIPRO',
                        textAlign: TextAlign.center, style: TextStyle(color: Colors.grey, fontSize: 11)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
