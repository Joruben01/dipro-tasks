import 'package:flutter/material.dart';
import 'package:dipro_tasks/models/models.dart';
import 'package:dipro_tasks/services/data_service.dart';
import 'package:dipro_tasks/screens/dashboard_tab.dart';
import 'package:dipro_tasks/screens/proyectos_tab.dart';
import 'package:dipro_tasks/screens/contable_tab.dart';
import 'package:dipro_tasks/screens/perfil_tab.dart';

// Contenedor principal con navegacion inferior. Se muestra despues del
// login y mantiene al usuario, el DataService y el estado de modo oscuro.
class HomeShell extends StatefulWidget {
  final Usuario usuario;
  final DataService dataService;
  final bool modoOscuro;
  final ValueChanged<bool> onCambiarModoOscuro;

  const HomeShell({
    super.key,
    required this.usuario,
    required this.dataService,
    required this.modoOscuro,
    required this.onCambiarModoOscuro,
  });

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tabIndex = 0;

  @override
  Widget build(BuildContext context) {
    final tabs = [
      DashboardTab(usuario: widget.usuario, dataService: widget.dataService),
      ProyectosTab(usuario: widget.usuario, dataService: widget.dataService),
      ContableTab(usuario: widget.usuario),
      PerfilTab(
        usuario: widget.usuario,
        modoOscuro: widget.modoOscuro,
        onCambiarModoOscuro: widget.onCambiarModoOscuro,
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dipro Tasks'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none),
            tooltip: 'Notificaciones',
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Sin notificaciones nuevas')),
              );
            },
          ),
        ],
      ),
      body: IndexedStack(index: _tabIndex, children: tabs),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (i) => setState(() => _tabIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.folder_outlined), label: 'Proyectos'),
          NavigationDestination(icon: Icon(Icons.calculate_outlined), label: 'Contable'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Perfil'),
        ],
      ),
    );
  }
}
