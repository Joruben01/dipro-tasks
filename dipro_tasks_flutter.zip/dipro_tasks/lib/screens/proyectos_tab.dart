import 'package:flutter/material.dart';
import 'package:dipro_tasks/models/models.dart';
import 'package:dipro_tasks/services/data_service.dart';
import 'package:dipro_tasks/screens/tareas_screen.dart';
import 'package:dipro_tasks/theme.dart';

class ProyectosTab extends StatefulWidget {
  final Usuario usuario;
  final DataService dataService;

  const ProyectosTab({super.key, required this.usuario, required this.dataService});

  @override
  State<ProyectosTab> createState() => _ProyectosTabState();
}

class _ProyectosTabState extends State<ProyectosTab> {
  List<Proyecto> _proyectos = [];
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final proyectos = await widget.dataService.obtenerProyectos();
    setState(() {
      _proyectos = proyectos;
      _cargando = false;
    });
  }

  Future<void> _nuevoProyecto() async {
    final nombreCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Nuevo proyecto'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: nombreCtrl, decoration: const InputDecoration(labelText: 'Nombre')),
            TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Descripcion')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Crear')),
        ],
      ),
    );
    if (ok != true || nombreCtrl.text.trim().isEmpty) return;
    final nuevo = Proyecto(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      nombre: nombreCtrl.text.trim(),
      descripcion: descCtrl.text.trim(),
      fechaCreacion: DateTime.now(),
      creador: widget.usuario.usuario,
      integrantes: [widget.usuario.usuario],
    );
    await widget.dataService.crearProyecto(nuevo);
    _cargar();
  }

  @override
  Widget build(BuildContext context) {
    if (_cargando) return const Center(child: CircularProgressIndicator());

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: _cargar,
        child: _proyectos.isEmpty
            ? ListView(children: const [
                Padding(
                  padding: EdgeInsets.all(32),
                  child: Text('Todavia no hay proyectos', textAlign: TextAlign.center),
                ),
              ])
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _proyectos.length,
                itemBuilder: (context, i) {
                  final p = _proyectos[i];
                  return Card(
                    child: ListTile(
                      title: Text(p.nombre),
                      subtitle: Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: LinearProgressIndicator(
                          value: p.avance,
                          color: DiproColors.azul,
                          backgroundColor: DiproColors.azulClaro,
                        ),
                      ),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => TareasScreen(
                          proyecto: p,
                          usuario: widget.usuario,
                          dataService: widget.dataService,
                        ),
                      )),
                    ),
                  );
                },
              ),
      ),
      floatingActionButton: widget.usuario.rol == RolUsuario.admin
          ? FloatingActionButton.extended(
              onPressed: _nuevoProyecto,
              backgroundColor: DiproColors.rojo,
              icon: const Icon(Icons.add),
              label: const Text('Proyecto'),
            )
          : null,
    );
  }
}
