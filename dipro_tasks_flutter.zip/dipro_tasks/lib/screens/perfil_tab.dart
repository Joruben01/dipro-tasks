import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:dipro_tasks/models/models.dart';
import 'package:dipro_tasks/theme.dart';

class PerfilTab extends StatefulWidget {
  final Usuario usuario;
  final bool modoOscuro;
  final ValueChanged<bool> onCambiarModoOscuro;

  const PerfilTab({
    super.key,
    required this.usuario,
    required this.modoOscuro,
    required this.onCambiarModoOscuro,
  });

  @override
  State<PerfilTab> createState() => _PerfilTabState();
}

class _PerfilTabState extends State<PerfilTab> {
  XFile? _foto;

  Future<void> _elegirFoto() async {
    final picker = ImagePicker();
    final origen = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt_outlined),
              title: const Text('Sacar foto'),
              onTap: () => Navigator.pop(context, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_outlined),
              title: const Text('Elegir de la galeria'),
              onTap: () => Navigator.pop(context, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (origen == null) return;
    final img = await picker.pickImage(source: origen);
    if (img != null) setState(() => _foto = img);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Center(
          child: GestureDetector(
            onTap: _elegirFoto,
            child: CircleAvatar(
              radius: 44,
              backgroundColor: DiproColors.azulClaro,
              backgroundImage: _foto != null ? FileImage(File(_foto!.path)) : null,
              child: _foto == null
                  ? Text(
                      widget.usuario.nombre.substring(0, 1),
                      style: const TextStyle(fontSize: 28, color: DiproColors.azul),
                    )
                  : null,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Center(
          child: TextButton(onPressed: _elegirFoto, child: const Text('Cambiar foto de perfil')),
        ),
        const SizedBox(height: 16),
        Center(child: Text(widget.usuario.nombre, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16))),
        Center(
          child: Text(
            widget.usuario.rol == RolUsuario.admin ? 'Administrador' : 'Usuario',
            style: const TextStyle(color: Colors.grey),
          ),
        ),
        const SizedBox(height: 24),
        SwitchListTile(
          title: const Text('Modo oscuro'),
          value: widget.modoOscuro,
          activeColor: DiproColors.rojo,
          onChanged: widget.onCambiarModoOscuro,
        ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.logout, color: DiproColors.rojo),
          title: const Text('Cerrar sesion'),
          onTap: () => Navigator.of(context).popUntil((r) => r.isFirst),
        ),
      ],
    );
  }
}
