import 'package:flutter/material.dart';
import 'package:dipro_tasks/models/models.dart';
import 'package:dipro_tasks/theme.dart';

// Checklists estandar por categoria contable. En la version conectada a
// Firebase esto se guarda como tareas dentro de un proyecto "Contable".
const Map<String, List<String>> _checklists = {
  'IVA': ['Revisar compras', 'Revisar ventas', 'Conciliar IVA', 'Presentar declaracion'],
  'IRE': ['Calcular ingresos', 'Calcular gastos deducibles', 'Presentar declaracion IRE'],
  'Conciliaciones': ['Conciliar bancos', 'Conciliar caja', 'Revisar diferencias'],
  'Inventario': ['Contar stock', 'Actualizar sistema', 'Reportar faltantes'],
  'Auditoria': ['Revisar documentacion', 'Verificar procesos', 'Informe final'],
};

const Map<String, IconData> _iconos = {
  'IVA': Icons.receipt_long_outlined,
  'IRE': Icons.description_outlined,
  'Conciliaciones': Icons.balance_outlined,
  'Inventario': Icons.inventory_2_outlined,
  'Auditoria': Icons.fact_check_outlined,
};

class ContableTab extends StatelessWidget {
  final Usuario usuario;

  const ContableTab({super.key, required this.usuario});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      padding: const EdgeInsets.all(16),
      crossAxisCount: 2,
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 1.1,
      children: categoriasContables.map((c) {
        return Card(
          child: InkWell(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => _ChecklistScreen(categoria: c),
            )),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(_iconos[c] ?? Icons.folder_outlined, size: 32, color: DiproColors.azul),
                  const SizedBox(height: 8),
                  Text(c, style: const TextStyle(fontWeight: FontWeight.w500)),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _ChecklistScreen extends StatefulWidget {
  final String categoria;
  const _ChecklistScreen({required this.categoria});

  @override
  State<_ChecklistScreen> createState() => _ChecklistScreenState();
}

class _ChecklistScreenState extends State<_ChecklistScreen> {
  late Map<String, bool> _items;

  @override
  void initState() {
    super.initState();
    _items = {for (final i in _checklists[widget.categoria] ?? []) i: false};
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.categoria)),
      body: ListView(
        children: _items.keys.map((titulo) {
          return CheckboxListTile(
            title: Text(titulo),
            value: _items[titulo],
            activeColor: DiproColors.rojo,
            onChanged: (v) => setState(() => _items[titulo] = v ?? false),
          );
        }).toList(),
      ),
    );
  }
}
