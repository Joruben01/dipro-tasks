import 'package:flutter/material.dart';
import 'package:dipro_tasks/models/models.dart';
import 'package:dipro_tasks/services/data_service.dart';
import 'package:dipro_tasks/theme.dart';

class DashboardTab extends StatefulWidget {
  final Usuario usuario;
  final DataService dataService;

  const DashboardTab({super.key, required this.usuario, required this.dataService});

  @override
  State<DashboardTab> createState() => _DashboardTabState();
}

class _DashboardTabState extends State<DashboardTab> {
  List<Proyecto> _proyectos = [];
  List<Tarea> _tareas = [];
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final proyectos = await widget.dataService.obtenerProyectos();
    final tareas = <Tarea>[];
    for (final p in proyectos) {
      tareas.addAll(await widget.dataService.obtenerTareas(p.id));
    }
    setState(() {
      _proyectos = proyectos;
      _tareas = tareas;
      _cargando = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_cargando) return const Center(child: CircularProgressIndicator());

    final pendientes = _tareas.where((t) => t.estado != EstadoTarea.terminado).length;
    final terminadas = _tareas.where((t) => t.estado == EstadoTarea.terminado).length;
    final vencidas = _tareas.where((t) => t.vencida).length;
    final misTareas = _tareas.where((t) => t.responsable == widget.usuario.usuario).toList();

    return RefreshIndicator(
      onRefresh: _cargar,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Hola, ${widget.usuario.nombre.split(' ').first}',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          Text(widget.usuario.rol == RolUsuario.admin ? 'Administrador' : 'Usuario',
              style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.9,
            children: [
              _metrica('Pendientes', pendientes, DiproColors.azulClaro, DiproColors.azul),
              _metrica('Terminadas', terminadas, const Color(0xFFEAF3DE), const Color(0xFF3B6D11)),
              _metrica('Vencidas', vencidas, DiproColors.rojoClaro, DiproColors.rojo),
              _metrica('Proyectos', _proyectos.length, const Color(0xFFF1EFE8), Colors.grey.shade700),
            ],
          ),
          const SizedBox(height: 20),
          const Text('Mis tareas', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          if (misTareas.isEmpty) const Text('No tenes tareas asignadas', style: TextStyle(color: Colors.grey)),
          ...misTareas.map((t) => Card(
                child: ListTile(
                  title: Text(t.titulo),
                  subtitle: Text('Vence ${t.fechaLimite.day}/${t.fechaLimite.month}'),
                  trailing: _badgePrioridad(t.prioridad),
                ),
              )),
        ],
      ),
    );
  }

  Widget _metrica(String titulo, int valor, Color fondo, Color texto) {
    return Container(
      decoration: BoxDecoration(color: fondo, borderRadius: BorderRadius.circular(10)),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(titulo, style: TextStyle(fontSize: 11, color: texto)),
          Text('$valor', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600, color: texto)),
        ],
      ),
    );
  }

  Widget _badgePrioridad(PrioridadTarea p) {
    final map = {
      PrioridadTarea.alta: [DiproColors.rojoClaro, DiproColors.rojo, 'Alta'],
      PrioridadTarea.media: [const Color(0xFFFAEEDA), const Color(0xFF854F0B), 'Media'],
      PrioridadTarea.baja: [const Color(0xFFEAF3DE), const Color(0xFF3B6D11), 'Baja'],
    };
    final v = map[p]!;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: v[0] as Color, borderRadius: BorderRadius.circular(6)),
      child: Text(v[2] as String, style: TextStyle(fontSize: 10, color: v[1] as Color)),
    );
  }
}
