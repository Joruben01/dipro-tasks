import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:dipro_tasks/models/models.dart';
import 'package:dipro_tasks/services/data_service.dart';
import 'package:dipro_tasks/theme.dart';

enum _Filtro { mias, equipo, vencidas }

class TareasScreen extends StatefulWidget {
  final Proyecto proyecto;
  final Usuario usuario;
  final DataService dataService;

  const TareasScreen({
    super.key,
    required this.proyecto,
    required this.usuario,
    required this.dataService,
  });

  @override
  State<TareasScreen> createState() => _TareasScreenState();
}

class _TareasScreenState extends State<TareasScreen> {
  List<Tarea> _tareas = [];
  bool _cargando = true;
  _Filtro _filtro = _Filtro.mias;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final tareas = await widget.dataService.obtenerTareas(widget.proyecto.id);
    setState(() {
      _tareas = tareas;
      _cargando = false;
    });
  }

  List<Tarea> get _filtradas {
    switch (_filtro) {
      case _Filtro.mias:
        return _tareas.where((t) => t.responsable == widget.usuario.usuario).toList();
      case _Filtro.vencidas:
        return _tareas.where((t) => t.vencida).toList();
      case _Filtro.equipo:
        return _tareas;
    }
  }

  Future<void> _nuevaTarea() async {
    final tituloCtrl = TextEditingController();
    String responsable = widget.usuario.usuario;
    PrioridadTarea prioridad = PrioridadTarea.media;
    XFile? foto;
    final picker = ImagePicker();

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Nueva tarea'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: tituloCtrl, decoration: const InputDecoration(labelText: 'Titulo')),
                const SizedBox(height: 8),
                DropdownButtonFormField<PrioridadTarea>(
                  value: prioridad,
                  decoration: const InputDecoration(labelText: 'Prioridad'),
                  items: PrioridadTarea.values
                      .map((p) => DropdownMenuItem(value: p, child: Text(p.name)))
                      .toList(),
                  onChanged: (v) => setDialogState(() => prioridad = v ?? PrioridadTarea.media),
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: () async {
                    // En un dispositivo real esto abre la camara para
                    // fotografiar una factura o comprobante.
                    final img = await picker.pickImage(source: ImageSource.camera);
                    setDialogState(() => foto = img);
                  },
                  icon: const Icon(Icons.camera_alt_outlined),
                  label: Text(foto == null ? 'Fotografiar comprobante' : 'Foto adjuntada'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
            ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Crear')),
          ],
        ),
      ),
    );

    if (ok != true || tituloCtrl.text.trim().isEmpty) return;
    final nueva = Tarea(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      proyectoId: widget.proyecto.id,
      titulo: tituloCtrl.text.trim(),
      descripcion: '',
      responsable: responsable,
      estado: EstadoTarea.pendiente,
      prioridad: prioridad,
      fechaLimite: DateTime.now().add(const Duration(days: 3)),
    );
    await widget.dataService.crearTarea(nueva);
    _cargar();
  }

  Future<void> _avanzarEstado(Tarea t) async {
    final siguiente = {
      EstadoTarea.pendiente: EstadoTarea.enProceso,
      EstadoTarea.enProceso: EstadoTarea.terminado,
      EstadoTarea.terminado: EstadoTarea.pendiente,
    }[t.estado]!;
    await widget.dataService.actualizarEstadoTarea(t.id, siguiente);
    _cargar();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.proyecto.nombre)),
      floatingActionButton: FloatingActionButton(
        onPressed: _nuevaTarea,
        backgroundColor: DiproColors.rojo,
        child: const Icon(Icons.add),
      ),
      body: _cargando
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Wrap(
                    spacing: 8,
                    children: [
                      ChoiceChip(
                        label: const Text('Mis tareas'),
                        selected: _filtro == _Filtro.mias,
                        onSelected: (_) => setState(() => _filtro = _Filtro.mias),
                      ),
                      ChoiceChip(
                        label: const Text('Tareas del equipo'),
                        selected: _filtro == _Filtro.equipo,
                        onSelected: (_) => setState(() => _filtro = _Filtro.equipo),
                      ),
                      ChoiceChip(
                        label: const Text('Vencidas'),
                        selected: _filtro == _Filtro.vencidas,
                        onSelected: (_) => setState(() => _filtro = _Filtro.vencidas),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: _filtradas.isEmpty
                      ? const Center(child: Text('No hay tareas en este filtro'))
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          itemCount: _filtradas.length,
                          itemBuilder: (context, i) {
                            final t = _filtradas[i];
                            return Card(
                              child: ListTile(
                                title: Text(t.titulo),
                                subtitle: Text(
                                    'Responsable: ${t.responsable} - vence ${t.fechaLimite.day}/${t.fechaLimite.month}'),
                                trailing: TextButton(
                                  onPressed: () => _avanzarEstado(t),
                                  child: Text(_estadoTexto(t.estado)),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }

  String _estadoTexto(EstadoTarea e) {
    switch (e) {
      case EstadoTarea.pendiente:
        return 'Pendiente';
      case EstadoTarea.enProceso:
        return 'En proceso';
      case EstadoTarea.terminado:
        return 'Terminado';
    }
  }
}
