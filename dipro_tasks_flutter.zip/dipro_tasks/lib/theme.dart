import 'package:flutter/material.dart';

// Paleta de marca DIPRO: rojo, azul y blanco.
class DiproColors {
  static const azul = Color(0xFF0C447C);
  static const azulClaro = Color(0xFFE6F1FB);
  static const rojo = Color(0xFFE24B4A);
  static const rojoClaro = Color(0xFFFCEBEB);
  static const blanco = Color(0xFFFFFFFF);
}

ThemeData buildLightTheme() {
  return ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: DiproColors.blanco,
    colorScheme: ColorScheme.fromSeed(
      seedColor: DiproColors.azul,
      brightness: Brightness.light,
      primary: DiproColors.azul,
      secondary: DiproColors.rojo,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: DiproColors.azul,
      foregroundColor: Colors.white,
      elevation: 0,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: DiproColors.rojo,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    ),
  );
}

ThemeData buildDarkTheme() {
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: const Color(0xFF121212),
    colorScheme: ColorScheme.fromSeed(
      seedColor: DiproColors.azul,
      brightness: Brightness.dark,
      primary: const Color(0xFF85B7EB),
      secondary: const Color(0xFFF09595),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF042C53),
      foregroundColor: Colors.white,
      elevation: 0,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: DiproColors.rojo,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    ),
  );
}
