// Modelos de datos de Dipro Tasks.
// Estas clases reflejan las colecciones de Firestore descritas en la
// especificacion: usuarios, proyectos, tareas y archivos.

enum RolUsuario { admin, usuario }

enum EstadoTarea { pendiente, enProceso, terminado }

enum PrioridadTarea { alta, media, baja }

class Usuario {
  final String id;
  final String nombre;
  final String usuario;
  final RolUsuario rol;
  final String? fotoUrl;

  Usuario({
    required this.id,
    required this.nombre,
    required this.usuario,
    required this.rol,
    this.fotoUrl,
  });

  factory Usuario.fromMap(String id, Map<String, dynamic> data) {
    return Usuario(
      id: id,
      nombre: data['nombre'] ?? '',
      usuario: data['usuario'] ?? '',
      rol: (data['rol'] == 'admin') ? RolUsuario.admin : RolUsuario.usuario,
      fotoUrl: data['fotoUrl'],
    );
  }

  Map<String, dynamic> toMap() => {
        'nombre': nombre,
        'usuario': usuario,
        'rol': rol == RolUsuario.admin ? 'admin' : 'usuario',
        'fotoUrl': fotoUrl,
      };
}

class Proyecto {
  final String id;
  final String nombre;
  final String descripcion;
  final DateTime fechaCreacion;
  final String creador;
  final List<String> integrantes;
  final double avance; // 0.0 a 1.0

  Proyecto({
    required this.id,
    required this.nombre,
    required this.descripcion,
    required this.fechaCreacion,
    required this.creador,
    this.integrantes = const [],
    this.avance = 0.0,
  });

  factory Proyecto.fromMap(String id, Map<String, dynamic> data) {
    return Proyecto(
      id: id,
      nombre: data['nombre'] ?? '',
      descripcion: data['descripcion'] ?? '',
      fechaCreacion: DateTime.tryParse(data['fecha_creacion'] ?? '') ?? DateTime.now(),
      creador: data['creador'] ?? '',
      integrantes: List<String>.from(data['integrantes'] ?? []),
      avance: (data['avance'] ?? 0.0).toDouble(),
    );
  }

  Map<String, dynamic> toMap() => {
        'nombre': nombre,
        'descripcion': descripcion,
        'fecha_creacion': fechaCreacion.toIso8601String(),
        'creador': creador,
        'integrantes': integrantes,
        'avance': avance,
      };
}

class Tarea {
  final String id;
  final String proyectoId;
  final String titulo;
  final String descripcion;
  final String responsable;
  final EstadoTarea estado;
  final PrioridadTarea prioridad;
  final DateTime fechaLimite;
  final List<String> archivoIds;

  Tarea({
    required this.id,
    required this.proyectoId,
    required this.titulo,
    required this.descripcion,
    required this.responsable,
    required this.estado,
    required this.prioridad,
    required this.fechaLimite,
    this.archivoIds = const [],
  });

  bool get vencida => estado != EstadoTarea.terminado && fechaLimite.isBefore(DateTime.now());

  factory Tarea.fromMap(String id, Map<String, dynamic> data) {
    return Tarea(
      id: id,
      proyectoId: data['proyecto'] ?? '',
      titulo: data['titulo'] ?? '',
      descripcion: data['descripcion'] ?? '',
      responsable: data['responsable'] ?? '',
      estado: _estadoDesde(data['estado']),
      prioridad: _prioridadDesde(data['prioridad']),
      fechaLimite: DateTime.tryParse(data['fecha_limite'] ?? '') ?? DateTime.now(),
      archivoIds: List<String>.from(data['archivoIds'] ?? []),
    );
  }

  Map<String, dynamic> toMap() => {
        'proyecto': proyectoId,
        'titulo': titulo,
        'descripcion': descripcion,
        'responsable': responsable,
        'estado': estado.name,
        'prioridad': prioridad.name,
        'fecha_limite': fechaLimite.toIso8601String(),
        'archivoIds': archivoIds,
      };

  static EstadoTarea _estadoDesde(String? v) {
    switch (v) {
      case 'enProceso':
        return EstadoTarea.enProceso;
      case 'terminado':
        return EstadoTarea.terminado;
      default:
        return EstadoTarea.pendiente;
    }
  }

  static PrioridadTarea _prioridadDesde(String? v) {
    switch (v) {
      case 'alta':
        return PrioridadTarea.alta;
      case 'baja':
        return PrioridadTarea.baja;
      default:
        return PrioridadTarea.media;
    }
  }
}

class ArchivoAdjunto {
  final String id;
  final String tareaId;
  final String nombreArchivo;
  final String url;

  ArchivoAdjunto({
    required this.id,
    required this.tareaId,
    required this.nombreArchivo,
    required this.url,
  });

  factory ArchivoAdjunto.fromMap(String id, Map<String, dynamic> data) {
    return ArchivoAdjunto(
      id: id,
      tareaId: data['tarea'] ?? '',
      nombreArchivo: data['nombre_archivo'] ?? '',
      url: data['url'] ?? '',
    );
  }

  Map<String, dynamic> toMap() => {
        'tarea': tareaId,
        'nombre_archivo': nombreArchivo,
        'url': url,
      };
}

// Categorias fijas del modulo de Control Contable.
const List<String> categoriasContables = [
  'IVA',
  'IRE',
  'Conciliaciones',
  'Inventario',
  'Auditoria',
];
