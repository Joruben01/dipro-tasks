import 'package:flutter/material.dart';
import 'package:dipro_tasks/services/data_service.dart';
import 'package:dipro_tasks/screens/login_screen.dart';
import 'package:dipro_tasks/theme.dart';

// NOTA IMPORTANTE:
// Esta version usa MockDataService (datos en memoria) para que la app
// compile y funcione de inmediato, sin necesitar todavia un proyecto de
// Firebase real. Cuando Jorge cree su proyecto de Firebase y agregue
// android/app/google-services.json, hay que:
//   1. Descomentar Firebase.initializeApp() abajo.
//   2. Cambiar MockDataService() por FirebaseDataService() (ver la
//      plantilla al final de lib/services/data_service.dart).
//
// import 'package:firebase_core/firebase_core.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // await Firebase.initializeApp();
  runApp(const DiproTasksApp());
}

class DiproTasksApp extends StatefulWidget {
  const DiproTasksApp({super.key});

  @override
  State<DiproTasksApp> createState() => _DiproTasksAppState();
}

class _DiproTasksAppState extends State<DiproTasksApp> {
  final DataService _dataService = MockDataService();
  bool _modoOscuro = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dipro Tasks',
      debugShowCheckedModeBanner: false,
      theme: buildLightTheme(),
      darkTheme: buildDarkTheme(),
      themeMode: _modoOscuro ? ThemeMode.dark : ThemeMode.light,
      home: LoginScreen(
        dataService: _dataService,
        modoOscuro: _modoOscuro,
        onCambiarModoOscuro: (v) => setState(() => _modoOscuro = v),
      ),
    );
  }
}
