// Capa de datos de Dipro Tasks.
//
// MockDataService guarda todo en memoria para que la app compile y se
// pueda probar YA, sin necesitar un proyecto de Firebase.
//
// Cuando Jorge cree su proyecto de Firebase y agregue el archivo
// android/app/google-services.json, se debe reemplazar MockDataService
// por FirebaseDataService (dejado como plantilla comentada al final de
// este archivo) y agregar las dependencias firebase_core, cloud_firestore
// y firebase_storage en pubspec.yaml (ya estan listadas, solo hay que
// descomentar el codigo de inicializacion en main.dart).

import 'package:dipro_tasks/models/models.dart';

abstract class DataService {
  Future<Usuario?> login(String usuario, String password);
  Future<List<Proyecto>> obtenerProyectos();
  Future<Proyecto> crearProyecto(Proyecto proyecto);
  Future<List<Tarea>> obtenerTareas(String proyectoId);
  Future<Tarea> crearTarea(Tarea tarea);
  Future<void> actualizarEstadoTarea(String tareaId, EstadoTarea estado);
  Future<List<Usuario>> obtenerUsuarios();
}

class MockDataService implements DataService {
  // Usuarios iniciales de la beta interna DIPRO.
  final List<Usuario> _usuarios = [
    Usuario(id: '1', nombre: 'Jorge Venialgo', usuario: 'jorge', rol: RolUsuario.admin),
    Usuario(id: '2', nombre: 'Carlos Gonzalez', usuario: 'carlos', rol: RolUsuario.usuario),
    Usuario(id: '3', nombre: 'Camila Alvarenga', usuario: 'camila', rol: RolUsuario.usuario),
  ];

  // Password de prueba unica para la beta. En produccion esto se
  // reemplaza por Firebase Authentication (email/password).
  final String _passwordDemo = '1234';

  final List<Proyecto> _proyectos = [
    Proyecto(
      id: 'p1',
      nombre: 'Auditoria 2026',
      descripcion: 'Auditoria interna anual',
      fechaCreacion: DateTime(2026, 2, 20),
      creador: 'jorge',
      integrantes: ['jorge', 'carlos'],
      avance: 0.6,
    ),
    Proyecto(
      id: 'p2',
      nombre: 'IVA Marzo',
      descripcion: 'Control IVA',
      fechaCreacion: DateTime(2026, 2, 27),
      creador: 'jorge',
      integrantes: ['jorge', 'carlos', 'camila'],
      avance: 0.3,
    ),
  ];

  final List<Tarea> _tareas = [
    Tarea(
      id: 't1',
      proyectoId: 'p2',
      titulo: 'Revisar compras',
      descripcion: 'Revisar comprobantes de compra de marzo',
      responsable: 'carlos',
      estado: EstadoTarea.enProceso,
      prioridad: PrioridadTarea.alta,
      fechaLimite: DateTime.now().add(const Duration(days: 4)),
    ),
    Tarea(
      id: 't2',
      proyectoId: 'p2',
      titulo: 'Fotografiar comprobante',
      descripcion: 'Subir foto del comprobante de venta',
      responsable: 'camila',
      estado: EstadoTarea.pendiente,
      prioridad: PrioridadTarea.baja,
      fechaLimite: DateTime.now().add(const Duration(days: 6)),
    ),
    Tarea(
      id: 't3',
      proyectoId: 'p1',
      titulo: 'Conciliar IVA',
      descripcion: 'Cruzar compras y ventas',
      responsable: 'jorge',
      estado: EstadoTarea.pendiente,
      prioridad: PrioridadTarea.media,
      fechaLimite: DateTime.now().add(const Duration(days: 1)),
    ),
  ];

  @override
  Future<Usuario?> login(String usuario, String password) async {
    await Future.delayed(const Duration(milliseconds: 400));
    if (password != _passwordDemo) return null;
    try {
      return _usuarios.firstWhere((u) => u.usuario == usuario);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<List<Proyecto>> obtenerProyectos() async {
    await Future.delayed(const Duration(milliseconds: 200));
    return List.unmodifiable(_proyectos);
  }

  @override
  Future<Proyecto> crearProyecto(Proyecto proyecto) async {
    _proyectos.add(proyecto);
    return proyecto;
  }

  @override
  Future<List<Tarea>> obtenerTareas(String proyectoId) async {
    await Future.delayed(const Duration(milliseconds: 200));
    return _tareas.where((t) => t.proyectoId == proyectoId).toList();
  }

  @override
  Future<Tarea> crearTarea(Tarea tarea) async {
    _tareas.add(tarea);
    return tarea;
  }

  @override
  Future<void> actualizarEstadoTarea(String tareaId, EstadoTarea estado) async {
    final idx = _tareas.indexWhere((t) => t.id == tareaId);
    if (idx == -1) return;
    final actual = _tareas[idx];
    _tareas[idx] = Tarea(
      id: actual.id,
      proyectoId: actual.proyectoId,
      titulo: actual.titulo,
      descripcion: actual.descripcion,
      responsable: actual.responsable,
      estado: estado,
      prioridad: actual.prioridad,
      fechaLimite: actual.fechaLimite,
      archivoIds: actual.archivoIds,
    );
  }

  @override
  Future<List<Usuario>> obtenerUsuarios() async => List.unmodifiable(_usuarios);
}

/*
// PLANTILLA para cuando ya exista el proyecto de Firebase real.
// 1. Agregar android/app/google-services.json (lo descargas de la consola
//    de Firebase).
// 2. Descomentar esta clase y usar FirebaseDataService() en main.dart en
//    lugar de MockDataService().
//
// class FirebaseDataService implements DataService {
//   final _db = FirebaseFirestore.instance;
//   final _auth = FirebaseAuth.instance;
//
//   @override
//   Future<Usuario?> login(String usuario, String password) async {
//     final query = await _db.collection('usuarios')
//         .where('usuario', isEqualTo: usuario).limit(1).get();
//     if (query.docs.isEmpty) return null;
//     final doc = query.docs.first;
//     if (doc.data()['password'] != password) return null;
//     return Usuario.fromMap(doc.id, doc.data());
//   }
//   ... (obtenerProyectos, crearTarea, etc. usando _db.collection('proyectos')
//        y _db.collection('tareas'), igual que en la especificacion)
// }
*/
