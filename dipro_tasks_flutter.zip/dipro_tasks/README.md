# Dipro Tasks

App interna DIPRO: proyectos, tareas y control contable. Flutter + Firebase (Firestore/Storage).

Este proyecto ya funciona con datos de prueba en memoria (`MockDataService`), sin necesitar Firebase.
Usuarios de prueba: `jorge` / `carlos` / `camila`, contrasena `1234`.

Para obtener el .apk instalable y conectar Firebase real, segui la guia
"Dipro Tasks - Especificacion y guia de implementacion" (Word) que acompana
este proyecto. Resumen:

1. Subir esta carpeta a un repositorio de GitHub.
2. Conectar el repositorio en Codemagic (usa el `codemagic.yaml` incluido) y compilar.
3. Descargar el `.apk` generado e instalarlo en Android.
4. Crear un proyecto en Firebase, agregar `android/app/google-services.json` y activar
   `FirebaseDataService` en `lib/services/data_service.dart` para tener datos reales
   en la nube.
